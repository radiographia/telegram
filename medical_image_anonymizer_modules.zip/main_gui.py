import os
import tkinter as tk
from tkinter import filedialog, messagebox
from core.anonymizer import anonymize_dicom_file, anonymize_directory
from pydicom.misc import is_dicom

def run_gui():
    root = tk.Tk()
    root.title("Medical DICOM Anonymizer")
# Установка иконки
    icon_path = os.path.join(os.path.dirname(__file__), '..', 'resources', 'bones.ico')
    icon_path = os.path.abspath(icon_path)
    if os.path.exists(icon_path):
        root.iconbitmap(icon_path)    
    root.geometry("500x300")

    input_var = tk.StringVar()
    output_var = tk.StringVar()
    mode_var = tk.StringVar(value="file")
    overwrite_var = tk.BooleanVar(value=False)

    def select_input():
        if mode_var.get() == "file":
            path = filedialog.askopenfilename(title="Выберите DICOM-файл")
            if path and is_dicom(path):
                input_var.set(path)
            elif path:
                messagebox.showerror("Ошибка", "Выбранный файл не является DICOM.")
        else:
            path = filedialog.askdirectory(title="Выберите папку с DICOM-файлами")
            if path:
                input_var.set(path)

    def select_output():
        path = filedialog.askdirectory(title="Выберите папку для вывода")
        if path:
            output_var.set(path)

    def run_anonymization():
        input_path = input_var.get()
        output_path = output_var.get()

        if not input_path or not output_path:
            messagebox.showwarning("Недостаточно данных", "Укажите вход и выход.")
            return

        try:
            if mode_var.get() == "file":
                anonymize_dicom_file(input_path, output_path, overwrite=overwrite_var.get())
            else:
                anonymize_directory(input_path, output_path, overwrite=overwrite_var.get())

            messagebox.showinfo("Готово", "Анонимизация завершена.")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Анонимизация не удалась:\n{e}")

    # --- UI Layout ---
    tk.Label(root, text="Что вы хотите анонимизировать?").pack(anchor="w", padx=10, pady=(10, 0))
    tk.Radiobutton(root, text="Один DICOM-файл", variable=mode_var, value="file").pack(anchor="w", padx=20)
    tk.Radiobutton(root, text="Папку с DICOM-файлами", variable=mode_var, value="folder").pack(anchor="w", padx=20)

    tk.Button(root, text="Выбрать входной файл/папку", command=select_input).pack(pady=(15, 0))
    tk.Entry(root, textvariable=input_var, width=60).pack(padx=10)

    tk.Button(root, text="Выбрать выходную папку", command=select_output).pack(pady=(10, 0))
    tk.Entry(root, textvariable=output_var, width=60).pack(padx=10)

    tk.Checkbutton(root, text="Перезаписывать существующие файлы", variable=overwrite_var).pack(pady=5)

    tk.Button(root, text="Анонимизировать", command=run_anonymization, bg="#007acc", fg="white", padx=10, pady=5).pack(pady=15)

    root.mainloop()
