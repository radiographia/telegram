import logging
from ui.main_gui import run_gui

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

if __name__ == "__main__":
    logging.info("=== Старт приложения ===")
    try:
        run_gui()
    except Exception:
        logging.exception("Ошибка при запуске GUI")
