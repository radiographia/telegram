import logging
import os

# ВАЖНО: отключаем регистрацию энкодеров ДО импорта pydicom
import types
import pydicom.encoders.base

pydicom.encoders.base.add_plugin = lambda *args, **kwargs: None

from pydicom import config
config.use_gdcm = False

from pydicom import dcmread, dcmwrite
from pydicom.uid import generate_uid
from pydicom.misc import is_dicom



TAG_BLACKLIST = [
    'PatientName', 'PatientID', 'PatientBirthDate', 'PatientSex',
    'InstitutionName', 'InstitutionAddress', 'ReferringPhysicianName',
    'StudyID', 'AccessionNumber', 'StudyDate', 'StudyTime',
    'SeriesDate', 'SeriesTime', 'PerformingPhysicianName',
    'OperatorsName', 'OtherPatientIDs', 'OtherPatientNames'
]

UID_TAGS = [
    #'StudyInstanceUID',
    # 'SeriesInstanceUID',  <-- УБРАТЬ эту строку
    'SOPInstanceUID',
    'MediaStorageSOPInstanceUID'
]




def anonymize_dicom_file(src_path, dst_path, overwrite=False):
    try:
        if not is_dicom(src_path):
            logging.warning(f"Пропущен (не DICOM): {src_path}")
            return

        ds = dcmread(src_path)
        ds.remove_private_tags()

        for tag in TAG_BLACKLIST:
            if hasattr(ds, tag):
                setattr(ds, tag, '')

        for tag in UID_TAGS:
            if hasattr(ds, tag):
                setattr(ds, tag, generate_uid())

        if os.path.isdir(dst_path):
            basename = os.path.basename(src_path)
            out_path = os.path.join(dst_path, basename)
        else:
            out_path = dst_path

        if os.path.exists(out_path) and not overwrite:
            logging.warning(f"Файл уже существует: {out_path}")
            return

        dcmwrite(out_path, ds)
        logging.info(f"Анонимизирован: {out_path}")

    except Exception as e:
        logging.error(f"Ошибка при обработке {src_path}: {e}")


def anonymize_directory(input_dir, output_dir, overwrite=False):
    for root, _, files in os.walk(input_dir):
        rel_path = os.path.relpath(root, input_dir)
        target_root = os.path.join(output_dir, rel_path)
        os.makedirs(target_root, exist_ok=True)

        for f in files:
            src = os.path.join(root, f)
            if is_dicom(src):  # ← 🔍 Это ключ
                anonymize_dicom_file(src, target_root, overwrite)